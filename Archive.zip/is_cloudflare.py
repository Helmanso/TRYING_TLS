import pyautogui
from selenium.webdriver.common.by import By

def is_cloudflare_waiting(driver):
    """
    Detects if Cloudflare verification is stuck
    """
    try:
        text = driver.execute_script("return document.body.innerText").lower()
        bg_color = driver.execute_script("return window.getComputedStyle(document.body, null).getPropertyValue('background-color');")

        return (
            "verify you are human" in text or
            "needs to review the security" in text or
            "cloudflare" in text or
            "checking your browser" in text or
            "please wait while we check" in text or
            "rgb(0" in bg_color or
            "rgb(17" in bg_color or
            "#000" in bg_color
        )
    except:
        return False
    
    
def click_at_position(x, y):
    """
    Moves mouse to (x, y) and clicks
    """
    pyautogui.moveTo(x, y, duration=0.5)
    pyautogui.click()
    print(f"🖱️ Clicked at ({x}, {y})")